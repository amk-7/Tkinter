### 📷 [ASCII-Webcam](https://github.com/micodeyt/ascii-webcam)

## INFO

> ✅ Affiche votre webcam en ASCII dans votre terminal !<br/>
> 🎥 Utilisé dans la vidéo : https://youtu.be/DBnStqiLB-Q<br/>
> 📍 Ce projet a été inspiré par : https://github.com/uvipen/ASCII-generator

## Installation

```sh
- git clone https://github.com/micodeyt/ascii-webcam

- cd /path

- pip install -r requirements.txt
```

## Utilisation

```sh
py cam.py
```
